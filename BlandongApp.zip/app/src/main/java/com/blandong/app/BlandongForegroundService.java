package com.blandong.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Foreground Service untuk menjalankan proses upload video YouTube di background.
 * Menggunakan Java murni dan support library.
 */
public class BlandongForegroundService extends Service {
    private static final String TAG = "BlandongService";
    public static final String CHANNEL_ID = "BlandongServiceChannel";
    public static final int NOTIFICATION_ID = 1;
    
    private String mApiKey;
    private String mYoutubeLinks;
    private String mOAuthToken; // Akan di-set dari MainActivity

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && WebAppInterface.ACTION_START_SERVICE.equals(intent.getAction())) {
            mApiKey = intent.getStringExtra(WebAppInterface.EXTRA_API_KEY);
            mYoutubeLinks = intent.getStringExtra(WebAppInterface.EXTRA_YOUTUBE_LINKS);
            mOAuthToken = intent.getStringExtra(WebAppInterface.EXTRA_OAUTH_TOKEN); // Ambil token dari Intent
            
            // Tampilkan notifikasi persisten dan mulai sebagai Foreground Service
            startForeground(NOTIFICATION_ID, buildNotification("BlandongApp sedang memproses video..."));

            // Jalankan proses di thread terpisah agar tidak memblokir UI (meskipun ini Service)
            new Thread(new Runnable() {
                @Override
                public void run() {
                    startProcessingTask();
                }
            }).start();
            
            return START_STICKY;
        } else if (intent != null && "STOP_SERVICE".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        
        return START_NOT_STICKY;
    }

    private void startProcessingTask() {
        logToUI("Service: Memulai proses upload...");
        logToFile("Service started at " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
        
        // --- Simulasi Proses ---
        // Di sini seharusnya ada logika:
        // 1. Parsing mYoutubeLinks (yang seharusnya sudah berisi link yang di-shorten)
        // 2. Inisialisasi YouTube Data API client menggunakan mOAuthToken
        // 3. Iterasi dan upload setiap video
        // 4. Update notifikasi dan logToUI secara berkala
        
        try {
            // Simulasi 3 video yang diupload
            for (int i = 1; i <= 3; i++) {
                String msg = "Service: Mengupload video ke-" + i + "...";
                logToUI(msg);
                updateNotification(msg);
                logToFile(msg);
                Thread.sleep(3000); // Tunggu 3 detik per video
            }
            
            String finalMsg = "Semua selesai. Video short sukses diupload ke channel YouTube.";
            logToUI(finalMsg);
            logToFile("Service finished successfully.");
            updateNotification(finalMsg);
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logToUI("Service: Proses diinterupsi.");
            logToFile("Service interrupted.");
        }
        
        // Hentikan service setelah selesai
        stopForeground(true);
        stopSelf();
    }
    
    private void logToUI(String message) {
        Log.d(TAG, message);
        Intent intent = new Intent(WebAppInterface.ACTION_LOG_UPDATE);
        intent.putExtra(WebAppInterface.EXTRA_LOG_MESSAGE, message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
    
    private void logToFile(String message) {
        try {
            File logFile = new File(getExternalFilesDir(null), "blandong_log.txt");
            FileWriter writer = new FileWriter(logFile, true);
            writer.append(new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()))
                  .append(" - ")
                  .append(message)
                  .append("\n");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            Log.e(TAG, "Gagal menulis ke log file: " + e.getMessage());
        }
    }

    private void createNotificationChannel() {
        // Hanya perlu untuk Android O (API 26) ke atas
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Blandong Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }
    
    private Notification buildNotification(String text) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Menggunakan NotificationCompat dari support library
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("BlandongApp")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_b) // Akan dibuat di Phase 3
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }
    
    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification(text));
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
