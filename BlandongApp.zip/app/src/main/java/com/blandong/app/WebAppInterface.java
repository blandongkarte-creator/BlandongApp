package com.blandong.app;

import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.support.v4.content.LocalBroadcastManager;

/**
 * Antarmuka JavaScript untuk menjembatani komunikasi antara WebView dan kode Java.
 * Semua metode yang dipanggil dari JS harus dianotasi dengan @JavascriptInterface.
 */
public class WebAppInterface {
    Context mContext;
    
    // Konstanta untuk BroadcastReceiver
    public static final String ACTION_START_SERVICE = "com.blandong.app.START_SERVICE";
    public static final String EXTRA_OAUTH_TOKEN = "oauth_token";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_YOUTUBE_LINKS = "youtube_links";
    public static final String ACTION_LOG_UPDATE = "com.blandong.app.LOG_UPDATE";
    public static final String EXTRA_LOG_MESSAGE = "log_message";

    /** Instantiate the interface and set the context */
    WebAppInterface(Context c) {
        mContext = c;
    }

    /** Tampilkan Toast dari JavaScript */
    @JavascriptInterface
    public void showToast(String toast) {
        Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
    }

    /** Terima token OAuth dari JavaScript setelah login sukses */
    @JavascriptInterface
    public void receiveOAuthToken(String token) {
        // Kirim token ke MainActivity atau langsung ke service
        Intent intent = new Intent(ACTION_LOG_UPDATE);
        intent.putExtra(EXTRA_LOG_MESSAGE, "Token OAuth diterima: " + (token.length() > 10 ? token.substring(0, 10) + "..." : token));
        LocalBroadcastManager.getInstance(mContext).sendBroadcast(intent);
        
        // Simpan token di SharedPreferences atau variabel statis untuk service
        // Untuk kesederhanaan, kita akan menyimpannya di SharedPreferences di MainActivity
        ((MainActivity)mContext).setOAuthToken(token);
    }

    /** Terima data dari JS dan mulai Foreground Service */
    @JavascriptInterface
    public void startProcessing(String apiKey, String youtubeLinks) {
        Intent intent = new Intent(mContext, BlandongForegroundService.class);
        intent.setAction(ACTION_START_SERVICE);
        intent.putExtra(EXTRA_API_KEY, apiKey);
        intent.putExtra(EXTRA_YOUTUBE_LINKS, youtubeLinks);
        
        // Mulai service
        // Untuk API 26+, kita harus menggunakan startForegroundService
        // Namun, untuk kompatibilitas AIDE lama (target 29), kita akan menggunakan startService
        // dan memastikan service memanggil startForeground() segera.
        mContext.startService(intent);
        
        Intent logIntent = new Intent(ACTION_LOG_UPDATE);
        logIntent.putExtra(EXTRA_LOG_MESSAGE, "Memulai proses background...");
        LocalBroadcastManager.getInstance(mContext).sendBroadcast(logIntent);
    }
    
    /** Terima log dari JavaScript untuk ditampilkan di log panel */
    @JavascriptInterface
    public void appendLog(String message) {
        Intent intent = new Intent(ACTION_LOG_UPDATE);
        intent.putExtra(EXTRA_LOG_MESSAGE, message);
        LocalBroadcastManager.getInstance(mContext).sendBroadcast(intent);
    }
}
