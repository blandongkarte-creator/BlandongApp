package com.blandong.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/**
 * Activity utama yang memuat WebView untuk UI dan logika JavaScript.
 * Menggunakan Java murni dan support library.
 */
public class MainActivity extends Activity {
    private WebView mWebView;
    private WebAppInterface mWebAppInterface;
    private String mOAuthToken = null; // Untuk menyimpan token OAuth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Menggunakan layout activity_main yang akan dibuat di Phase 3
        setContentView(R.layout.activity_main); 

        mWebView = (WebView) findViewById(R.id.webview);
        
        // Konfigurasi WebView
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true); // Penting untuk beberapa fungsi JS
        
        // Inisialisasi JS Bridge
        mWebAppInterface = new WebAppInterface(this);
        mWebView.addJavascriptInterface(mWebAppInterface, "Android");
        
        // Load HTML lokal dari assets
        mWebView.loadUrl("file:///android_asset/index.html");
        
        // Optional: Handle navigasi link di dalam WebView
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Di sini bisa ditambahkan logika untuk menangani login OAuth
                // Misalnya, jika URL adalah redirect URI, kita bisa mengambil token
                // Untuk demo, kita asumsikan JS di index.html yang menangani OAuth dan mengirim token via JS Bridge
                return false;
            }
        });
        
        // Daftarkan BroadcastReceiver untuk menerima log dari Service
        LocalBroadcastManager.getInstance(this).registerReceiver(
            mLogReceiver, new IntentFilter(WebAppInterface.ACTION_LOG_UPDATE));
    }
    
    /**
     * BroadcastReceiver untuk menerima pesan log dari Service dan mengirimkannya ke JavaScript
     * untuk ditampilkan di panel log WebView.
     */
    private BroadcastReceiver mLogReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra(WebAppInterface.EXTRA_LOG_MESSAGE);
            if (message != null) {
                // Kirim pesan log ke JavaScript
                final String jsCode = "javascript:appendLog('" + message.replace("'", "\\'") + "')";
                mWebView.post(new Runnable() {
                    @Override
                    public void run() {
                        mWebView.loadUrl(jsCode);
                    }
                });
                
                // Jika service selesai, tampilkan Toast
                if (message.contains("Semua selesai.")) {
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                }
            }
        }
    };
    
    /**
     * Dipanggil dari WebAppInterface untuk menyimpan token OAuth.
     * @param token Token OAuth yang diterima.
     */
    public void setOAuthToken(String token) {
        this.mOAuthToken = token;
        Toast.makeText(this, "Token OAuth berhasil disimpan di Activity.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        // Hapus pendaftaran receiver
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mLogReceiver);
        super.onDestroy();
    }
}
